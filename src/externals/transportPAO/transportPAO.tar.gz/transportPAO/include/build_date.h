
!
! Copyright (C) 2010 WanT Group
!
! This file is distributed under the terms of the
! GNU General Public License. See the file "License"
! in the root directory of the present distribution,
! or http://www.gnu.org/copyleft/gpl.txt .
!

#define   __CONF_BUILD_DATE           "Sun 22 Jan 2017 04:35:54 PM CST"

